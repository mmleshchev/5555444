
https://docs.djangoproject.com/en/4.1/topics/db/models/

https://docs.djangoproject.com/en/4.1/ref/models/

https://docs.djangoproject.com/en/4.1/ref/models/querysets/

https://docs.djangoproject.com/en/4.1/ref/models/database-functions/

https://docs.djangoproject.com/en/4.1/topics/db/queries/

https://docs.djangoproject.com/en/4.1/topics/db/queries/#complex-lookups-with-q

https://docs.djangoproject.com/en/4.1/topics/db/sql/









